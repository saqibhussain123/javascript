// async function harry(){
//     // return 5
// }
// harry().then((x)=>{
//     alert(x)
// })
// harry.catch((x)=>{
//     alert("error solve"+x)
// })



async function harry(params) {
    let dehliweather =new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve('17 Degree')
        },1000)
    })
    let mumbaiweather =new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve('20 Degree')
        },2000)
    })
    // dehliweather.then(alert);
    // mumbaiweather.then(alert);
     console.log("Fetching dehliweather please wait....");
     let dehliw= await dehliweather
     console.log("Fetching dehliwather :"+dehliw);
     
     console.log("Fetching mumbai weather please wait....");
     let mumbaiw=await mumbaiweather
     console.log("Fetching dehliwather :"+mumbaiw);
    return [dehliw,mumbaiw]
}


const cherry= async()=>{
    console.log("Hey I am cherry and i am Waiting for you");
    
}
const main1=async()=>{

    console.log("welcome to weather control room");
     let a =harry();
     let b=cherry();
     a.then((value)=>{
       console.log(value);
       
     })
}
main1();



