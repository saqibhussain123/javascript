let count=true;
let countvalue= new Promise(function (resolve,reject){
    if (count) {
        resolve("this is a count value")
    }else{
        reject("this is no count values")

    } 
})
     

console.log(countvalue);
 

// for /of


const student=['john','sara','jack'];

for(let element of student){
    console.log(element);
    
}



// Arrow function 
// Es5
// var x =function (x,y){
//     return x*y
// }
// x(2,3)

//Es6

// const x=(x,y)=>x*y single line function 



// let sum =(a,b)=>{
//     return a+b
// }
// console.log(sum(1,2))


// let x=1;
// if (x===1) {
//     let x=2;
//     console.log("this is function scope in js"+x);
    
// }
// console.log("this is outer function scope in js"+x);
// const y=32;
// y=45;
// console.log(y);



//default function


function defalutfunction(x,y=10){

    return x+y
}
console.log( defalutfunction(5,3));



//Object Destructuring
//Es5
// var person ={
//     name:'john',
//     age:30
// };
// var name =person.name;
// var age=person.age;

// console.log(name);
// console.log(age);


//Es6

// const person={
//     name:"ali",
//     age:34
// }
// const{name,age}=person
// console.log(person);

// Spread operater
// Es5

var aar1=[1,2,3];
var arr2=[4,5,6];
var comb=aar1.concat(arr2)
console.log(comb);
// Es6
var combine=[...aar1,...arr2]
console.log(combine);



//string concatenation
var FirstName="saqib "
var lastName="hussain"
var FullName=FirstName +''+lastName;
console.log("es5"+FullName);

const FullNam=`${FirstName} ${lastName}`
console.log(FullNam);
