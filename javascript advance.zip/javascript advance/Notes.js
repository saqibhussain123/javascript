// // 1 Filter Unique values in Array

// const Array=[1,1,2,3,6,6,3,1]
// const uniquearray=[...new Set(Array)];
// document.writeln(uniquearray);

// // 2 convert to Boolean

// const istrue=!1;
// const alsoFalse=!!1;
// console.log(typeof(istrue))
// console.log(istrue);
// console.log(typeof(alsoFalse))
// console.log(alsoFalse);

// // 3 convert to string


// const Value=5+"";
// console.log(typeof(Value));


// // 4 convert to integer

// let int="14";
// int =+int;
// console.log(typeof(int)+int);


// //5  convert float to int




// const float=98.5| 0;
// console.log(typeof(float)+float);

// //6  Remove last digits


// const remove=1153/10|0;
// console.log(typeof(remove)+remove);



// //7  Truncate an array


// let array=[0,1,2,3,4,5]

// array.length=3;
// console.log(array);


//8 last item in array
//  let last=[0,1,2,3,4];
//  last.splice(-1)
//  console.log("last item in slice"+last);
 


function addition (a,b){
    console.log(addition);
    return a+b;
    
}
addition(12,6)


// const addition=(a,b)=>a+b