
// Array with Reduce Method

// const Array=[23,56,67,45];
//  let a =Array.map((value,index,array)=>{
//  console.log("this is a value",value,"this is a index no",index,"this is a array",array);

//  return value+index
 
// });
// Array.forEach(value => {
//     console.log( "this is a foreach loop",value);
    
// });
// console.log(a);




// alert("what is your name ")
// let ab =prompt("enter your name here")
// confirm(`are you shower ${ab}`)
 

// alert("enter you value");
// let abc=prompt("enter your value here");
// abc=Number.parseInt(abc)
// alert(`your enterd type of is ${typeof abc}`)
// confirm(`${abc}`)


// let filter=[45,56,6,34,56,67];
// let a2=filter.filter((a) =>{
//  return a>50;
// })
// console.log(a2);


// let red=[34,45,3,23,45];
// let a3=red.reduce((b,c)=>{
//     return b+c
// })
// console.log(a3);



// let a=prompt("what is your name");
// let b=prompt("what is your age");
// let c=prompt("enter your fsv color");
// console.log(`your name is ${a} and age is ${b} and fav color is ${c} `);
// document.writeln(`your name is ${a} and age is ${b} and fav color is ${c} `);



// setTimeout(function(){
//     console.log("hey iam a good");
    
// },1000)





// class and object


// class busServices{
//     submit(){
//         console.log("form submitted");
//     }
//     cancel(){
//         console.log("form cancel");
//     }
//  a=prompt("enter your name here").busServices;
 
// }



// let harrayform=new busServices;
// harrayform.fill("Harry");

// let rohanform=new busServices;
// rohanform.fill("rohan");

// harrayform.submit





// const sum=(a,b)=>{
// console.log("yes i am running"+(a+b));

// }
// setTimeout(sum,1000,1,2)








// const sum=(a,b)=>{
//     console.log(`yes iam running ${a+b}`);
    
// }
// setTimeout(sum,1000,1,3)


// Promoise





// let p=new Promise(function(resolve,reject){
//     let hello="saqib";
//     resolve(hello)
// // reject("error")
// })
// setTimeout(function(){
//     console.log("hello iam a settime out function ");
    
// },20000)

// console.log(p);


let p1= new Promise((resolve,reject)=>{
    console.log("promise is pending");
    setTimeout(()=>{
        console.log("i am promise and i am reslove");
        resolve(true)
        reject(new Error("i am an Error"))
    },5000)
});

let p2= new Promise((resolve,reject)=>{
    console.log("promise is pending");
    setTimeout(()=>{
        console.log("i am promise and i am rejected");
        // resolve(true)
        reject(new Error("i am an Error"))
    },5000)
})
// console.log(p1,p2);


p1.then((value)=>{
    console.log(value);
    let p3= new Promise((resolve,reject)=>{
        setTimeout(()=>{resolve("promise 2 reslove")},2000)
    })
    return p3
})

p2.catch((value)=>{
    console.log("some error occoured");
    
})




