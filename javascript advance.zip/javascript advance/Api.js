// Code with harry 

// let p = fetch("https://goweather.herokuapp.com/weather/London");
// p.then((resonse)=>{
    //     console.log(resonse.status);
    //     console.log(resonse.ok);
    //     console.log(resonse.text);
    //     console.log(resonse.headers);
    
//     return resonse.json()
// }).then((value2)=>{
//     console.log(value2);
    
// })

// Apna collage

  URL=("https://goweather.herokuapp.com/weather/London");
 //const URL=("https://cat-fact.herokuapp.com/facts");

 const getFetch=async()=>{
    console.log("getting data.....");
    let resonse=await fetch(URL)
    console.log(resonse.status);   
 }
 getFetch()