//Q1 array ma prompt input sa number add karna tha

// let arr=[23,345,454,565];
// let a=prompt('enter a number');
// a=Number.parseInt(a)

// arr.push(a)
// console.log(arr);



//Q2 keep adding number to array in q1 untill 0 is added to the array

// let arr=[23,3,45,56,54]
// let a;
// do{
//     a=prompt("enter a number")
//     a=Number.parseInt(a);
//     arr.push(a);
// }while (a !=0) {
//     console.log(arr);
    
// }



// let arr=[];
// let a;
// do {
//     a=prompt("Enter a number");
//     a=Number.parseInt(a);
//     arr.push(a);
// } while (a !=0){
//     console.log(arr);
    
// }


//Q3 fILTER FOR Number DIVISIBLE BY 5 FROM A GIVIN  ARRAY

let arr=[30,45,45,332,34,40,47]
// let n=arr.filter((x)=>{
//     return x%5 ==0
// })
// console.log(n);

//     // Q4

// let p=arr.map((a)=>{
//     return a*a;
// })
// console.log(p);

// Q5

// let Red=arr.reduce((r1,r2)=>{
//     return r1+r2
// }
// )
// console.log(Red);
  



// chapter 6

// Q1 Agr user ki age 18 ki zayada ha to you can drive and less than 18 you con not drive


// let age=prompt("Enter your age");
// age=Number.parseInt(age);
// console.log(age);
 
// const canDrive=(age)=>{
//     return age>=18?true:false
// }
// if (canDrive(age)) {
//     console.log("yes you can drive");
    
// }else{
//     console.log("dont drive");
    
// }

// Q1 use confirm to ask the user if he wants to see the prompt again

// let RunAgain=true;
// const canDrive=(age)=>{
//     return age>=18?true:false
// }

// while(RunAgain){
//     let age=prompt("Enter your age");
//     age=Number.parseInt(age)

//     if (age<0) {
//         console.error("plase valid error")
//         alert("plase valid age")
//         break;
//     }
//     if (canDrive(age)) {
//         alert("you can drive")
//     }else{
//         alert("you can not drive")
//     }
//     RunAgain=confirm("Do you Wants to play Again")
// }
    
// Q3 

// in the previous q use console.error to log the error if the age is negative


// Q4 so here what i wants is if the user enter a number greater than 4 redirect google 



// let number =prompt("Enter your number");
// number=Number.parseInt(number);
// if(number>4){
//     location.href("http://google.com")
// }


// Q5 so the last Q is change is change the bacground of the page to yellow or red
// or any other color based on user input throught prompt

// let color=prompt("enter a page backgrong color")
// document.body.style.background=color




// chapter no 8




// Q1 write a program to show different alerts when d/f button are clicked
{/* <button onclick="alert('please give me one plate of chowman')">chowman</button>
<button onclick="alert('please give me one plate of chowman')"></button>
<button onclick="alert('please give me one plate of chowman')"></button> */}


// chapter no 9 

const Loadscript = async(src)=>{
    return new Promise((resolve,reject)=>{
  let script =document.createElement("script")
    script.src=src
    script.onload=()=>{
        resolve(src+ "Done Success")
    }
    document.head.append(script)
    })
  
}



const main=async()=>{
    console.log(new Date().getSeconds());   
    let a=await Loadscript("")
    console.log(new Date);
    console.log(a);
    
}
main();