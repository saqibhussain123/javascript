//  string Method


let hello="Hello".charAt(4);
console.log(hello);

let hell="Hello".concat("",'word');
console.log(hell);

let hel="Hello".startsWith("H");
console.log(hel);

let he="Hello".endsWith("o");
console.log(he);

let h="Hello".includes("x");
console.log(h);

let names="Hello".indexOf("l");
console.log(names);

let nam="Hello".lastIndexOf("l");
console.log(nam);