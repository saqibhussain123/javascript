// const student={
//     fullname:"saqib",
//     Marks:94.4,
//     printMarks:function(){
//         console.log("Marks =",this.Marks);
        
//     },   
// }

// let arr=['apple','banan','mango']
//     console.log(arr);
// const employee={
//     calcTax(){
//         console.log("tax rate a 10%");
        
//     }
// }




// function sum(a,b){
//     console.log(a+b);
// }
// function calculator(a,b,sumcallback){
//     sumcallback(a,b);

// }
// calculator(1,2,sum());




// const hello =()=>{
//   console.log("hello");
// }
// setTimeout(hello,3000);





// let age=4;
// if(age >=18){
//     if(age >= 60){
//         console.log("senior");
        
//     }else{
//         console.log("middle");
        
//     }
// }else{
//     console.log("child");
    
// }

// const getpromise=()=>{
//     return new Promise((resolve,reject)=>{
//     console.log("i am a promise");
    
//     });
// };

// let promise=getpromise();
// promise.then((res)=>{
//     console.log("promise fulfilled",err);
    
// });
// promise.catch((err)=>{
// console.log("rejected ",err);

// })


// // this go ha yo corrent context to access or refer karta ha  

// const user ={
//     username:"saqib",
//     price:999,
//     WelcomeMessage:function(){
//         console.log(`${this.username}, welcome to website`);
//         console.log(this);
        
        
//     }
// }
// user.WelcomeMessage();
// user.username="ali"
// user.WelcomeMessage();
// console.log(this);


// function one(){
//     let username="ali"
// console.log(this.username)
// }
// one()


// const chai=function(){
//     let username="hitesh"
//     console.log(this.username);
    
// }
// chai();

// const chai=()=>{
//     let username="hitesh"
//     console.log(this);
    
// }
// chai();

const chai=(num1,num2)=>{
    return num1+num2
}
console.log(chai(2,4))

// arrow function


// emplecent return

// const addTwo=(num1,num2)=>num1+num2 or
// const addTwo=(num1,num2)=>(num1+num2) or
const addTwo=(num1,num2)=>({username:"hitesh"})
console.log(addTwo(30,20));


